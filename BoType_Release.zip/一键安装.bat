@echo off
chcp 65001 >nul
echo 请求管理员权限安装证书并启动 BoType 安装程序...

:: 检查管理员权限
net session >nul 2>&1
if %errorLevel% == 0 (
    goto :admin
) else (
    echo 正在请求获取管理员权限，请在弹出的窗口中点“是”...
    powershell -Command "Start-Process '%~dpnx0' -Verb RunAs"
    exit /b
)

:admin
echo =========================================
echo 安装 BoType 开发证书以通过 Office 校验...
echo =========================================
certutil -addstore "Root" "%~dp0BoType_TemporaryKey.cer" >nul
certutil -addstore "TrustedPublisher" "%~dp0BoType_TemporaryKey.cer" >nul
echo 证书导入完成。

echo 正在启动 setup.exe...
start "" "%~dp0setup.exe"
